<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://js.stripe.com/v3/"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <div class="main-panel">
          
    <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Cancelled Orders</h4>
                   
                    <table class="table table-bordered" style="text-align: center;">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Order Id </th>
                          <th> Seller Name </th>
                          <th> Buyer Name </th>
                          <th> Order Date </th>
                          <th> Order Cost </th>
                          <th> View </th>
                          <th> Action </th>

                        </tr>
                      </thead>
                      <tbody>
                      <?php $index =1; ?>
            <?php if(!empty($newordersrecords)): ?>
                <?php $__currentLoopData = $newordersrecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newordersrecords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td> <?php echo e($index); ?> </td>
                          <td> <?php echo e($newordersrecords['_id']); ?> </td>
                          <td> <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->_id == $newordersrecords['sellerId']): ?>
                                            <?php echo e($user->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </td>
                          <td> <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->_id == $newordersrecords['userId']): ?>
                                            <?php echo e($user->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </td>
                          <td> <?php echo e($newordersrecords['orderDate']->toDateTime()->format('d-m-Y')); ?> </td>
                          <?php 
                            if(isset($newordersrecords['totalprice'])) {
                                $totalprice = $newordersrecords['totalprice'];
                            } else {
                                $totalprice = $newordersrecords['price'];
                            }
                          ?>
                          <td> <?php echo e($newordersrecords['currency'].' '.$totalprice); ?> </td>

                          <td>
                            <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                        <a href="<?php echo e(route('orders.view', ['orderId' => $newordersrecords['_id'], 'page'=>'delivered'])); ?>"><button class="btn btn-info align-text-top border-0"><i class="fa fa-eye"></i></button></a>
                      </div>
                          </td>
                        
                            <td>
                             <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                        <button class="btn btn-info align-text-top border-0" data-toggle="modal" data-target="#userModalCenter<?php echo e($newordersrecords['_id']); ?>">Approve</button>


                      <div class="modal fade " id="userModalCenter<?php echo e($newordersrecords['_id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content" style="width: 90%;">
                    <div class="modal-header" style="border:none; width:98%;">
                        <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(__('Are you sure to proceed this?')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    
                    <div class="modal-footer" style="display:block; padding:20px !important;">
                        
                       <input type="hidden" value="<?php echo $newordersrecords['sellerId']; ?>" id="sellerId_<?php echo $newordersrecords['_id']; ?>" >
                       <input type="hidden" value="pk_test_45R1I607r03YqDfi6xmB1U9M" id="stripekey_<?php echo $newordersrecords['_id']; ?>" >
                        <input type="hidden" value="<?php echo $newordersrecords['price']; ?>" id="amount_<?php echo $newordersrecords['_id']; ?>" >
                         <input type="hidden" value="<?php echo $newordersrecords['currencyCode']; ?>" id="currency_<?php echo $newordersrecords['_id']; ?>" >
                        
                        <input type="hidden" value="<?php echo $newordersrecords['_id']; ?>" id="orderid" >
                            <a href="<?php echo e(route('orders.refundorder', ['orderId' => $newordersrecords['_id']])); ?>" style="cursor: pointer;">
                                <button type="button" style="background-color: #8862e0; border-color: #8862e0" class="btn btn-danger"><?php echo e(__('Refund')); ?></button>
                            </a>
                        
                    </div>
                </div>
            </div>
        </div>
                      </div>
                          </td>

                          
                        </tr>
                        <?php $index++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php else: ?>
                        <tr>
                            <td colspan="8">No records found</td>
                        </tr>
                            <?php endif; ?>
                      </tbody>
                    </table>
                        <div class="pagination-wrapper justify-content-center" style="display:grid; margin-top:25px;"> <?php echo $pagination->render(); ?> </div>
                  </div>
                </div>
              </div>


</div>
</div>


<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/orders/cancelledorders.blade.php ENDPATH**/ ?>