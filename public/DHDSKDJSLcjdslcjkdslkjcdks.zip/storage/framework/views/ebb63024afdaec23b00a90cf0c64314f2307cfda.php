<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Add Commission</h4>
                    <form class="forms-sample" action="<?php echo e(route('commissions.store')); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="exampleInputName1">Commission Percentage</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Percentage" name="percentage" required>
                         <?php if($errors->has('percentage')): ?><p class="text-danger"><?php echo e($errors->first('percentage')); ?></p><?php endif; ?>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">Minimum Range</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Min Range" name="minrange" required>
                         <?php if($errors->has('minrange')): ?><p class="text-danger"><?php echo e($errors->first('minrange')); ?></p><?php endif; ?>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">Maximum Range</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Max Range" name="maxrange" required>
                         <?php if($errors->has('maxrange')): ?><p class="text-danger"><?php echo e($errors->first('maxrange')); ?></p><?php endif; ?>
                      </div>
                      
                        
                          
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/commissions/create.blade.php ENDPATH**/ ?>