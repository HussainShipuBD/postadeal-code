<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-panel">
          
    <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">New Orders</h4>
                   
                    <table class="table table-bordered" style="text-align: center;">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Order Id </th>
                          <th> Seller Name </th>
                          <th> Buyer Name </th>
                          <th> Order Date </th>
                          <th> Order Cost </th>
                          <th> View </th>

                        </tr>
                      </thead>
                      <tbody>
                      <?php $index =1; ?>
            <?php if(!empty($newordersrecords)): ?>
                <?php $__currentLoopData = $newordersrecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newordersrecords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td> <?php echo e($index); ?> </td>
                          <td> <?php echo e($newordersrecords['_id']); ?> </td>
                          <td> <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->_id == $newordersrecords['sellerId']): ?>
                                            <?php echo e($user->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </td>
                          <td> <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->_id == $newordersrecords['userId']): ?>
                                            <?php echo e($user->name); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </td>
                          <td> <?php echo e($newordersrecords['orderDate']->toDateTime()->format('d-m-Y')); ?> </td>
                          <?php 
                            if(isset($newordersrecords['totalprice'])) {
                                $totalprice = $newordersrecords['totalprice'];
                            } else {
                                $totalprice = $newordersrecords['price'];
                            }
                          ?>
                          <td> <?php echo e($newordersrecords['currency'].' '.$totalprice); ?> </td>

                          <td>
                            <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                        <a href="<?php echo e(route('orders.view', ['orderId' => $newordersrecords['_id'], 'page'=>'neworders'])); ?>"><button class="btn btn-info align-text-top border-0"><i class="fa fa-eye"></i></button></a>
                      </div>
                          </td>
                          
                        </tr>
                        <?php $index++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php else: ?>
                        <tr>
                            <td colspan="8">No records found</td>
                        </tr>
                            <?php endif; ?>
                      </tbody>
                    </table>
                        <div class="pagination-wrapper justify-content-center" style="display:grid; margin-top:25px;"> <?php echo $pagination->render(); ?> </div>
                  </div>
                </div>
              </div>


</div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/orders/refundedorders.blade.php ENDPATH**/ ?>