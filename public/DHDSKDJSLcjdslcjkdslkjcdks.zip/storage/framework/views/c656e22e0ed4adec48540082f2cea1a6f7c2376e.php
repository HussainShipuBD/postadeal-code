<div class="form-group">
                            <label for="exampleInputName1">Sub Category</label>
                            
                              <select class="form-control" id="sub-category-type" name="sub_category_type" required>
                                <option value="">Select</option>
                                <?php if(!empty($subcategories)): ?>
				    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($eachcategory->_id); ?>"> 
					    <?php echo e($eachcategory->name); ?>

					</option>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
				    <?php endif; ?>
                              </select>
                            </div>
<?php /**PATH /var/www/html/resources/views/admin/ajax/subcategories-select.blade.php ENDPATH**/ ?>