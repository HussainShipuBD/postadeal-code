<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Add Super Category</h4>
                    <form class="forms-sample" action="<?php echo e(route('supercategories.store')); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    	<input type="hidden" id="ajax_url" url="<?php echo e(route('supercategories.ajaxsubcategories')); ?>" required/>
                      <div class="form-group">
                        <label for="exampleInputName1">Super Category Name</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Name" name="category_name" required>
                          <?php if($errors->has('category_name')): ?><p class="text-danger"><?php echo e($errors->first('category_name')); ?></p><?php endif; ?>
                      </div>
                      
                          <div class="form-group">
                            <label for="exampleInputName1">Parent Category</label>
                            
                              <select class="form-control" id="category-type" name="main_category_type" required>
                                <option value="">Select</option>
				    <?php $__currentLoopData = $maincategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($eachcategory->_id); ?>"> 
					    <?php echo e($eachcategory->name); ?>

					</option>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                              </select>
                               <?php if($errors->has('main_category_type')): ?><p class="text-danger"><?php echo e($errors->first('main_category_type')); ?></p><?php endif; ?>
                            </div>
                            
                            <div class="form-group" id="super_sub_category">

                               <?php if($errors->has('sub_category_type')): ?><p class="text-danger"><?php echo e($errors->first('sub_category_type')); ?></p><?php endif; ?>
				                    </div>
                          
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>
<script>
	window.onload = function (e) {
      document.getElementById("category-type").selectedIndex = 0;
    };
</script>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/supercategories/create.blade.php ENDPATH**/ ?>