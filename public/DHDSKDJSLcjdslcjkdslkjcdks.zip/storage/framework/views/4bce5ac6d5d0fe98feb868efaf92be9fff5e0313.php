<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Edit Commission</h4>
                    <form class="forms-sample" action="<?php echo e(route('commissions.update',['commissionId' => $commissiondetails->_id])); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="exampleInputName1">Commission Percentage</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Percentage" name="percentage" value="<?php echo e($commissiondetails->percentage); ?>" required>
                         <?php if($errors->has('percentage')): ?><p class="text-danger"><?php echo e($errors->first('percentage')); ?></p><?php endif; ?>
                         <input type="hidden" class="form-control" id="exampleInputName1" placeholder="Percentage" name="hiddenpercentage" value="<?php echo e($commissiondetails->percentage); ?>" required>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">Minimum Range</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Min Range" name="minrange" value="<?php echo e($commissiondetails->minrange); ?>" required>
                         <?php if($errors->has('minrange')): ?><p class="text-danger"><?php echo e($errors->first('minrange')); ?></p><?php endif; ?>
                         <input type="hidden" class="form-control" id="exampleInputName1" placeholder="Min Range" name="hiddenminrange" value="<?php echo e($commissiondetails->minrange); ?>" required>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">Maximum Range</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Max Range" name="maxrange" value="<?php echo e($commissiondetails->maxrange); ?>" required>
                         <?php if($errors->has('maxrange')): ?><p class="text-danger"><?php echo e($errors->first('maxrange')); ?></p><?php endif; ?>
                         <input type="hidden" class="form-control" id="exampleInputName1" placeholder="Max Range" name="hiddenmaxrange" value="<?php echo e($commissiondetails->maxrange); ?>" required>
                      </div>
                      
                        
                          
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/commissions/edit.blade.php ENDPATH**/ ?>