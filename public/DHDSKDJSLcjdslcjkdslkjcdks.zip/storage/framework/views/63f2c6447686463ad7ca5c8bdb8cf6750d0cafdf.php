<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Change Password</h4>
                    <form class="forms-sample" action="<?php echo e(route('settings.adminpasswordupdate')); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="exampleInputName1">Old Password</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Old Password" name="admin_old_password" value="" required>

                         <?php if($errors->has('admin_old_password')): ?><p class="text-danger"><?php echo e($errors->first('admin_old_password')); ?></p><?php endif; ?>

                      </div>


                      <div class="form-group">

                        <label for="exampleInputName2">New Password</label>
                        <input type="text" class="form-control" id="exampleInputName2" placeholder="New Password" name="admin_new_password" value="" required>

                        <?php if($errors->has('admin_new_password')): ?><p class="text-danger"><?php echo e($errors->first('admin_new_password')); ?></p><?php endif; ?>

                      </div>

                       <div class="form-group">

                        <label for="exampleInputName2">Confirm Password</label>
                        <input type="text" class="form-control" id="exampleInputName2" placeholder="Confirm Password" name="admin_confirm_password" value="" required>

                         <?php if($errors->has('admin_confirm_password')): ?><p class="text-danger"><?php echo e($errors->first('admin_confirm_password')); ?></p><?php endif; ?>

                      </div>


                      
                        
                          
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/settings/editadminpassword.blade.php ENDPATH**/ ?>