<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
textarea#CKEditor1 { display: none;}

</style>
<script src="<?php echo e(URL::asset('public/admin_assets/js/ckeditor.js')); ?>"></script>

    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Add Help Page</h4>
                    <form class="forms-sample" action="<?php echo e(route('helps.store')); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="exampleInputName1">Title</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Title" name="title" required>
                        <?php if($errors->has('title')): ?><p class="text-danger"><?php echo e($errors->first('title')); ?></p><?php endif; ?>
                      </div>
                      

                      <div class="form-group">
                        <label for="exampleInputName1">Description</label>
                        <textarea id="editor1" name="description" required>
                        </textarea>
                        <?php if($errors->has('description')): ?><p class="text-danger"><?php echo e($errors->first('description')); ?></p><?php endif; ?>

                      </div>
                        
                          
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/helps/create.blade.php ENDPATH**/ ?>