<!DOCTYPE html>
<html>
<head>
	<title>Laravel 5.6 CRUD Application</title>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>


<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>


</body>
</html><?php /**PATH /var/www/html/resources/views/books/layout.blade.php ENDPATH**/ ?>