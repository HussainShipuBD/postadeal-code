<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Add Currency</h4>
                    <form class="forms-sample" action="<?php echo e(route('currency.store')); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    	<div class="form-group">
                            <label for="exampleInputName1">Currency Details</label>
                            
                              <select  name="currency_details" class="form-control" id="currency-currencydetails" onchange="addCurrencyCode();" required>
                                <option value="">Select</option>
				    <?php $__currentLoopData = $currencylist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($key); ?>"> 
					    <?php echo e($currency); ?>

					</option>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                              </select>
                            </div>
                    
                      <div class="form-group">
                        <label for="exampleInputName1">Currency Code</label>
        		<input type="text" class="form-control" id="currency-currencycode" name="currencycode" placeholder="" value="" readonly>
            <?php if($errors->has('currencycode')): ?><p class="text-danger"><?php echo e($errors->first('currencycode')); ?></p><?php endif; ?>
                      </div>
                      
                      <div class="form-group">
                        <label for="exampleInputName1">Currency Symbol</label>
        		 <input type="text" class="form-control" id="currency-currencysymbol" name="currencysymbol" placeholder="" value="" readonly>
               <?php if($errors->has('currencysymbol')): ?><p class="text-danger"><?php echo e($errors->first('currencysymbol')); ?></p><?php endif; ?>
                      </div>
                      
                      <div class="form-group">
                        <label for="exampleInputName1">Currency Name</label>
        		<input type="text" class="form-control" id="currency-currencyname" name="currencyname" placeholder="" value="" readonly>
              <?php if($errors->has('currencycode')): ?><p class="text-danger"><?php echo e($errors->first('currencycode')); ?></p><?php endif; ?>
                      </div>
                      
                        
                          
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/currency/create.blade.php ENDPATH**/ ?>