<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Notification Settings Management</h4>
                    <form class="forms-sample" action="<?php echo e(route('settings.notificationsettingsupdate')); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    

                      <div class="form-group">
                        <label for="exampleInputName1">API Key for Push Notification</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Push Notification Key" name="notificationkey" value="<?php echo e($settings->notificationkey); ?>" required>
                         <?php if($errors->has('notificationkey')): ?><p class="text-danger"><?php echo e($errors->first('notificationkey')); ?></p><?php endif; ?>
                      </div>

                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/settings/notificationsetting.blade.php ENDPATH**/ ?>