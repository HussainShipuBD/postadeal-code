<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="main-panel">
          
    <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Main Categories</h4>
                     <a href="<?php echo e(route('category.create')); ?>"><button type="button" class="btn btn-primary btn-fw">Add Category</button></a>
                    <form class="ml-auto search-form d-md-block" style="margin: 10px 0px;" action="<?php echo e(route('category.search')); ?>">
			    <div class="form-group">
			      <input type="search" class="form-control" placeholder="Search Categories" value="<?php echo e($search); ?>" name="search">
			    </div>
          		</form>

                    <table class="table table-bordered" style="text-align: center;">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Category name </th>
                          <th> Edit </th>
                          <th> Delete </th>
                          
                        </tr>
                      </thead>
                      <tbody>
                      <?php $index =1; ?>
            <?php if(!empty($categoryrecords)): ?>
                <?php $__currentLoopData = $categoryrecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td> <?php echo e($index); ?> </td>
                          <td> <?php echo e($category['name']); ?> </td>
                          <td>
                            <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                        <a href="<?php echo e(route('category.edit', ['categoryId' => $category['_id'], ])); ?>"><button class="btn btn-info align-text-top border-0"><i class="fa fa-edit"></i></button></a>
                      </div>
                          </td>
                          <td>
                             <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                         <a href="<?php echo e(route('category.delete', ['categoryId' => $category['_id'], ])); ?>">
                        <button class="btn btn-info align-text-top border-0"><i class="fa fa-trash-o"></i></button>
                      </a>
                      </div>
                          </td>
                        </tr>
                        <?php $index++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                      </tbody>
                    </table>
                        <div class="pagination-wrapper justify-content-center" style="display:grid; margin-top:25px;"> <?php echo $pagination->render(); ?> </div>
                  </div>
                </div>
              </div>
</div>

</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/categories/index.blade.php ENDPATH**/ ?>