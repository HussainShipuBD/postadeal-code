<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Edit Super Category</h4>
                    <form class="forms-sample" action="<?php echo e(route('supercategories.update',['categoryId' => $categorydetails->_id])); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    	<input type="hidden" id="ajax_url" url="<?php echo e(route('supercategories.ajaxsubcategories')); ?>" required/>
                      <div class="form-group">
                       <input type="text" class="form-control" id="exampleInputName1" placeholder="Name" name="supercategory_name" value="<?php echo e($categorydetails->name); ?>" required>

                        <input type="hidden" class="form-control" id="exampleInputName1" placeholder="Name" name="supercategory_hiddenname" value="<?php echo e($categorydetails->name); ?>" required>
                        <input type="hidden" class="form-control" id="exampleInputName2" name="parentcategory_hiddenid" value="<?php echo e($categorydetails->parentCategory); ?>" required>
                        <input type="hidden" class="form-control" id="exampleInputName3" name="subcategory_hiddenid" value="<?php echo e($categorydetails->subCategory); ?>" required>
                         <?php if($errors->has('category_name')): ?><p class="text-danger"><?php echo e($errors->first('category_name')); ?></p><?php endif; ?>

                      </div>
                      
                          <div class="form-group">
                            <label for="exampleInputName1">Parent Category</label>
                            
                              <select class="form-control" id="maincategory-type" name="main_category_type" required>
                                <option value="">Select</option>

            <?php $__currentLoopData = $maincategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($eachcategory[0]->_id); ?>" <?php if(strval($categorydetails->parentCategory) === $eachcategory[0]->_id): ?> selected <?php endif; ?>>   
              <?php echo e($eachcategory[0]->name); ?>

          </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                              </select>
                              <?php if($errors->has('main_category_type')): ?><p class="text-danger"><?php echo e($errors->first('main_category_type')); ?></p><?php endif; ?>
                            </div>
                            
                            <div class="form-group" id="super_sub_category">
                            <label for="exampleInputName1">Sub Category</label>
                            
                              <select class="form-control" id="edit-sub-category-type" name="sub_category_type" required>
                                <option value="">Select</option>
            <?php $__currentLoopData = $subcategoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachsubcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($eachsubcategory->_id); ?>" <?php if(strval($categorydetails->subCategory) === $eachsubcategory->_id): ?> selected <?php endif; ?>>    
              <?php echo e($eachsubcategory->name); ?>

          </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </select>
            <?php if($errors->has('sub_category_type')): ?><p class="text-danger"><?php echo e($errors->first('sub_category_type')); ?></p><?php endif; ?>
				</div>
                          
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>
<script>
	window.onload = function (e) {
      document.getElementById("category-type").selectedIndex = 0;
    };
</script>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/supercategories/edit.blade.php ENDPATH**/ ?>