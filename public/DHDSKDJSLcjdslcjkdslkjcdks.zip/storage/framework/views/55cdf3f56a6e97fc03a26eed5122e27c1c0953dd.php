<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-panel">
          
    <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Manage Commission</h4>
                     <a href="<?php echo e(route('commissions.create')); ?>"><button type="button" class="btn btn-primary btn-fw">Add Commission</button></a>
                   
                    <table class="table table-bordered" style="text-align: center; margin-top:20px;">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th> Commission Percentage </th>
                          <th> Minimum Range </th>
                          <th> Maximum Range </th>
                          <th> Edit </th>
                          <th> Delete </th>
                          
                        </tr>
                      </thead>
                      <tbody>
                      <?php $index =1; ?>
            <?php if(!empty($commissionrecords)): ?>
                <?php $__currentLoopData = $commissionrecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commissionrecords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td> <?php echo e($index); ?> </td>
                          <td> <?php echo e($commissionrecords['percentage']); ?> </td>
                          <td> <?php echo e($commissionrecords['minrange']); ?> </td>
                          <td> <?php echo e($commissionrecords['maxrange']); ?> </td>
                          <td>
                            <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                        <a href="<?php echo e(route('commissions.edit', ['commissionId' => $commissionrecords['_id'], ])); ?>"><button class="btn btn-info align-text-top border-0"><i class="fa fa-edit"></i></button></a>
                      </div>
                          </td>
                          <!--<td>
                             <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                        <a href="<?php echo e(route('commissions.delete', ['commissionId' => $commissionrecords['_id'], ])); ?>">
                        <button class="btn btn-info align-text-top border-0"><i class="fa fa-trash-o"></i></button>
                      </a>
                      </div>
                          </td>-->


                          <td>
                             <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                        <button class="btn btn-info align-text-top border-0" data-toggle="modal" data-target="#userModalCenter<?php echo e($commissionrecords['_id']); ?>">Delete</button>


                      <div class="modal fade " id="userModalCenter<?php echo e($commissionrecords['_id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content" style="width: 90%;">
                    <div class="modal-header" style="border:none; width:98%;">
                        <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(__('Do you want to delete this commission?')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    
                    <div class="modal-footer" style="display:block; padding:20px !important;">
                        
                       
                            <a href="<?php echo e(route('commissions.delete', ['commissionId' => $commissionrecords['_id'], 'itemStatus' => 1 ])); ?>" style="cursor: pointer;">
                                <button type="button" style="background-color: #8862e0; border-color: #8862e0" class="btn btn-danger"><?php echo e(__('Confirm')); ?></button>
                            </a>
                        
                    </div>
                </div>
            </div>
        </div>
                      </div>
                          </td>
                        </tr>
                        <?php $index++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php else: ?>
                        <tr>
                            <td colspan="8">No records found</td>
                        </tr>
                            <?php endif; ?>
                      </tbody>
                    </table>
                        <div class="pagination-wrapper justify-content-center" style="display:grid; margin-top:25px;"> <?php echo $pagination->render(); ?> </div>
                  </div>
                </div>
              </div>
</div>
</div>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/commissions/index.blade.php ENDPATH**/ ?>