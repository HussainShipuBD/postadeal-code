<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:22px;">View Product Details</h4>
                    <?php if($page == "approved") { ?>
                    <a href="<?php echo e(route('products.approved')); ?>"><button type="button" class="btn btn-primary btn-fw">Back</button></a>
                  <?php } else if($page == "pending"){ ?>
                    <a style="float: right;" href="<?php echo e(route('products.pending')); ?>"><button type="button" class="btn btn-primary btn-fw">Back</button></a>
                  <?php } else { ?>
                    <a style="float: right;" href="<?php echo e(route('products.reports')); ?>"><button type="button" class="btn btn-primary btn-fw">Back</button></a>
                  <?php } ?>
                      <div class="form-group" style="font-size:14px;">
                        
                        <!--<input type="file" accept="image/image/gif,image/jpeg" id="wizard-itempicture" name="product_image" class="form-control m-b15 p-2 borderGrey w-100"><br>-->
                        <?php $images = json_decode($itemdetails->images, TRUE); 
                        $imgCount = count($images); ?>
                        <input type="hidden" value ="<?php echo $imgCount; ?>" id="imgCount">
                        <div id="ProductImageView"></div>
                        <?php foreach($images as $i=>$image) { ?>

                        <img src="<?php echo e(url('/storage/app/public/products/thumb300/'.$image)); ?>" class="borderCurve borderGradient picture-src dnone" id="wizardPicturePreview"
              style="width:150px;height:150px;object-fit: cover; margin-top:20px;">
                           <input type = "hidden" name = "productImage[]" value="<?php echo $image; ?>">
                      <?php } ?>
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Product Name : </label>
                        <label style="font-size:17px;"><?php echo e($itemdetails->itemTitle); ?></label>
                       
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Product Description : </label>
                        <label style="font-size:17px;"><?php echo e($itemdetails->itemDesc); ?></label>
                       
                      </div>

                       <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Price : </label>
                        <label style="font-size:17px;"><?php echo e($itemdetails->price); ?>  <?php echo e($currencydetail->currencycode); ?></label>
                       
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Main Category : </label>
                        <label style="font-size:17px;"><?php echo e($categorydetail->name); ?></label>
                       
                      </div>

                      <?php if(!empty($subcategorydetail)) { ?>
                      <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Sub Category : </label>
                        <label style="font-size:17px;"><?php echo e($subcategorydetail->name); ?></label>
                       
                      </div>
                    <?php } ?>

                    <?php if(!empty($supercategorydetail)) { ?>
                      <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Super Category : </label>
                        <label style="font-size:17px;"><?php echo e($supercategorydetail->name); ?></label>
                       
                      </div>
                    <?php } ?>

                    <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Product Condition : </label>
                        <label style="font-size:17px;"><?php echo e($conditiondetail->name); ?></label>
                       
                      </div>
                      
                    <?php if(!empty($locationdetail)) { ?>

                      <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Location : </label>
                        <label style="font-size:17px;"><?php echo e($locationdetail->name); ?></label>
                       
                      </div>
                    <?php } ?>

                      <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Seller Name : </label>
                        <label style="font-size:17px;"><?php echo e($userdetail->name); ?></label>
                       
                      </div>

                      <?php if($itemdetails->buynow == "true") { ?>

                        <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Instant Buy : </label>
                        <label style="font-size:17px;">Enabled</label>
                       
                        </div>

                        <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Shipping Price : </label>
                        <label style="font-size:17px;"><?php echo e($itemdetails->shippingprice); ?>  <?php echo e($currencydetail->currencycode); ?></label>
                       
                        </div>

                      <?php } else { ?>

                        <div class="form-group">
                        <label for="exampleInputName1"  style="font-size:17px; font-weight:bold;">Instant Buy : </label>
                        <label style="font-size:17px;">Disabled</label>
                       
                        </div>

                      <?php } ?>
                      
                     
                          
                     
                  </div>
                </div>
              </div>
</div>
</div>

<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/products/view.blade.php ENDPATH**/ ?>