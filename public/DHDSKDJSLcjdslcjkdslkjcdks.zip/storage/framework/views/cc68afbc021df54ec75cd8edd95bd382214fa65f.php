<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Edit Sub Category</h4>
                    <form class="forms-sample" action="<?php echo e(route('subcategories.update',['categoryId' => $categorydetails->_id])); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="exampleInputName1">Sub Category Name</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Name" name="category_name" value="<?php echo e($categorydetails->name); ?>" required>
                          <?php if($errors->has('category_name')): ?><p class="text-danger"><?php echo e($errors->first('category_name')); ?></p><?php endif; ?>

                        <input type="hidden" class="form-control" id="exampleInputName1" name="category_hiddenname" value="<?php echo e($categorydetails->name); ?>" required>
                        <input type="hidden" class="form-control" id="exampleInputName2" name="parentcategory_hiddenid" value="<?php echo e($categorydetails->parentCategory); ?>" required>


                      </div>
                      
                          <div class="form-group">
                            <label for="exampleInputName1">Category</label>
                            
                              <select class="form-control" name="category_parent" id="category-type" required>
                                <option value="">Select</option>
				    <?php $__currentLoopData = $maincategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eachcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($eachcategory->_id); ?>" <?php if(strval($categorydetails->parentCategory) === $eachcategory->_id): ?> selected <?php endif; ?>>  
					    <?php echo e($eachcategory->name); ?>

					</option>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                              </select>
                                 <?php if($errors->has('category_parent')): ?><p class="text-danger"><?php echo e($errors->first('category_parent')); ?></p><?php endif; ?>
                            </div>
                          
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/subcategories/edit.blade.php ENDPATH**/ ?>