<?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.layouts.flashmessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-panel">
          
    <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="font-size:18px;">Edit Main Category</h4>
                    
                    <form class="forms-sample" action="<?php echo e(route('category.update',['categoryId' => $categorydetails->_id])); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="exampleInputName1">Category Name</label>
                        <input type="text" class="form-control" id="exampleInputName1" placeholder="Name" name="category_name" value="<?php echo e($categorydetails->name); ?>" required>
                        <?php if($errors->has('category_name')): ?><p class="text-danger"><?php echo e($errors->first('category_name')); ?></p><?php endif; ?>
                        <input type="hidden" class="form-control" id="exampleInputName1" placeholder="Name" name="category_hiddenname" value="<?php echo e($categorydetails->name); ?>" required>

                      </div>
                      <!--<div class="form-group">
                        <label for="exampleInputTitle">Meta Title</label>
                        <input type="text" class="form-control" id="exampleInputTitle" placeholder="Meta Title" name="title">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputDesc">Meta Description</label>
                        <input type="text" class="form-control" id="exampleInputDesc" placeholder="Mest Description" name="desc">
                      </div>-->
                      <div class="form-group">
                        <label for="exampleInputFile1">Image upload(jpg, png, jpeg)</label>
                        <input type="file" accept="image/image/gif,image/jpeg" id="wizard-picture" name="category_image" class="form-control m-b15 p-2 borderGrey w-100"><br>
                        
                        <img src="<?php echo e(url('/storage/app/public/categories/'.$categorydetails->image)); ?>" class="borderCurve borderGradient picture-src dnone" id="wizardPicturePreview"
              style="width:100px;height:100px;object-fit: cover; margin-top:20px;">
                        <?php if($errors->has('category_image')): ?><p class="text-danger"><?php echo e($errors->first('category_image')); ?></p><?php endif; ?>
                      </div>
                      
                      <button type="submit" class="btn btn-success mr-2">Submit</button>
                      
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/resources/views/admin/categories/edit.blade.php ENDPATH**/ ?>