<?php

namespace App\Models;
use App\Models\Currency;


use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class Product extends Eloquent
{
    
    protected $connection = 'mongodb';
    protected $collection = 'products';
    protected $fillable = [
        'itemTitle',
        "itemDesc",
        "itemType",
        'userId',
        "images",
        "price",
        'mainCategory',
        "subCategory",
        "superCategory",
        'CurrencyID',
        "locationID",
        "productCondition",
        'status',
        "featured",
        "reportCount",
        "reportDate"
    ];

    
}


