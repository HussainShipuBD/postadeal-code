<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class User extends Eloquent
{
    
    protected $connection = 'mongodb';
    protected $collection = 'users';
    protected $fillable = [
        'userId',
        "name",
        "email",
        'password',
        "mobile",
        "image",
        'status',
        'emailVerification',
        'stripeSecretKey',
        'stripePublicKey'
    ];
    
}
