<?php
namespace App\Classes;
use Session;

use App\Models\Setting;
use App\Models\Help;


use Config;
use Illuminate\Support\Facades\Mail;
class MyClass
{
    public static function site_settings()
    {
        $siteSettings = Setting::first();
        return $siteSettings;
    }

    public static function helps()
    {
        $helpdetails = Help::get();
        return $helpdetails;
    }


    public function push_notification($token, $title, $to)
    {
        $fcmUrl = 'https://fcm.googleapis.com/fcm/send';
        $siteSettings = Setting::first();
        
            $notification = [
                "id"=>"admin",
                "type" => "admin"
            ];
        
       
        //$notification_data = array('notification_data' =>json_encode($notification) );

        
            $fcmNotification = [
                'registration_ids' => $token,
                "notification" => [
                    "body" => $title,
                    "title" => $siteSettings->siteName." "."Team",
                ],
                'data' => $notification,
                'sound' => true,
                'priority' => 'high'
            ];
        

        $headers = [
            'Authorization: key='.$siteSettings->notificationkey,
            'Content-Type: application/json'
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$fcmUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
        $result = curl_exec($ch);
        curl_close($ch);
        if(json_decode($result)->success == 1) {
            return true;    
        }

    }

    
    
}
?>
